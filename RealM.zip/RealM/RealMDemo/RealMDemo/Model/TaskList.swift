//
//  TaskList.swift
//  RealMDemo
//
//  Created by alpesh patel on 6/2/17.
//  Copyright © 2017 alpesh patel. All rights reserved.
//

import Foundation
import RealmSwift

class TaskList: Object {
    
    dynamic var name = ""
    dynamic var createdAt = NSDate()
    let tasks = List<Task>()
    
       
// Specify properties to ignore (Realm won't persist these)
    
//  override static func ignoredProperties() -> [String] {
//    return []
//  }
}
