//
//  Person.swift
//  RealMDemo
//
//  Created by alpesh patel on 6/6/17.
//  Copyright © 2017 alpesh patel. All rights reserved.
//

import Foundation
import RealmSwift

class Person: Object {
    
// Specify properties to ignore (Realm won't persist these)
    
//  override static func ignoredProperties() -> [String] {
//    return []
//  }
    
    dynamic var name = ""
    dynamic var age = 0
    dynamic var spouse: Person?
    let cars = List<Car>()
    
    override var description: String { return "Person {\(name), \(age), \(String(describing: spouse?.name))}" }
    
}
