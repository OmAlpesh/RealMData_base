//
//  Car.swift
//  RealMDemo
//
//  Created by alpesh patel on 6/6/17.
//  Copyright © 2017 alpesh patel. All rights reserved.
//

import Foundation
import RealmSwift

class Car: Object {
    
// Specify properties to ignore (Realm won't persist these)
    
//  override static func ignoredProperties() -> [String] {
//    return []
//  }
    
    dynamic var brand = ""
    dynamic var name: String?
    dynamic var year = 0
    
    override var description: String { return "Car {\(brand), \(String(describing: name)), \(year)}" }
}
